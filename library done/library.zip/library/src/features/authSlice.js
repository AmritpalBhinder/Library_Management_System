import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  user: null,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (state, action) => {
      state.user = action.payload;
      localStorage.setItem("auth", JSON.stringify({ user: action.payload }));
    },
    restore: (state) => {
      const raw = localStorage.getItem("auth");
      if (raw) {
        try {
          const parsed = JSON.parse(raw);
          state.user = parsed.user || null;
        } catch {
          state.user = null;
        }
      }
    },
    logout: (state) => {
  state.user = null;
  localStorage.removeItem("auth");
},

  },
});

export const { login, restore, logout } = authSlice.actions;
export default authSlice.reducer;
