import React, { useEffect, useState } from "react";
import "./Books.css";
import { useNavigate } from "react-router-dom";

const Books = () => {
  const [books, setBooks] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const booksPerPage = 6;

  const navigate = useNavigate();

  // Fetch books
  useEffect(() => {
    fetch("http://localhost:3000/books")
      .then((res) => res.json())
      .then((data) => setBooks(data))
      .catch((err) => console.error("Error fetching books:", err));
  }, []);

  const [searchTerm, setSearchTerm] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [selectedGenre, setSelectedGenre] = useState("All");

  // Extract unique genres
  const genres = ["All", ...new Set(books.map((book) => book.genre))];

  // Filter + sort
  const filteredBooks = books
    .filter(
      (book) =>
        (selectedGenre === "All" || book.genre === selectedGenre) &&
        (book.Title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          book.author.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortOrder === "asc") return a.rent - b.rent;
      return b.rent - a.rent;
    });

  // Pagination on filtered list
  const indexOfLastBook = currentPage * booksPerPage;
  const indexOfFirstBook = indexOfLastBook - booksPerPage;
  const currentBooks = filteredBooks.slice(indexOfFirstBook, indexOfLastBook);

  const totalPages = Math.ceil(filteredBooks.length / booksPerPage);

  const goToNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  return (
    <div className="books-container">
      <h2 className="books-title">All Books</h2>

      {/* Controls */}
      <div className="books-controls">
        <input
          type="text"
          placeholder="Search by title or author..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />

        <select
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value)}
          className="sort-dropdown"
        >
          <option value="asc">Sort by Rent: Low to High</option>
          <option value="desc">Sort by Rent: High to Low</option>
        </select>

        <select
          value={selectedGenre}
          onChange={(e) => setSelectedGenre(e.target.value)}
          className="genre-dropdown"
        >
          {genres.map((g) => (
            <option key={g} value={g}>
              {g}
            </option>
          ))}
        </select>
      </div>

      {/* Books Grid */}
      <div className="books-grid">
        {currentBooks.map((book) => (
          <div key={book.id} className="book-card">
            <img
              src={book.cover}
              alt={book.Title}
              onClick={() => navigate(`/books/${book.id}`)}
            />

            <h3 className="book-title">{book.Title}</h3>
            <p className="book-author">{book.author}</p>

            <div className="book-actions">
              <button
                className="edit-btn"
                onClick={() => navigate(`/books/edit/${book.id}`)}
              >
                ✏️ Edit
              </button>
              <button
                className="delete-btn"
                onClick={() => {
                  if (window.confirm("Are you sure to delete this book?")) {
                    fetch(`http://localhost:3000/books/${book.id}`, {
                      method: "DELETE",
                    })
                      .then(() => {
                        setBooks(books.filter((b) => b.id !== book.id));
                      })
                      .catch((err) => console.error(err));
                  }
                }}
              >
                🗑 Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="pagination">
        <button
          onClick={goToPrevPage}
          disabled={currentPage === 1}
          className="page-btn"
        >
          ⬅ Prev
        </button>
        <span className="page-info">
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={goToNextPage}
          disabled={currentPage === totalPages}
          className="page-btn"
        >
          Next ➡
        </button>
      </div>
    </div>
  );
};

export default Books;
