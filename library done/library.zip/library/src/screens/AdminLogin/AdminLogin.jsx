// // import React, { useState } from "react";
// // import { useNavigate } from "react-router-dom";
// // import "./AdminLogin.css";

// // export default function AdminLogin() {
// //   const [formData, setFormData] = useState({ username: "", password: "" });
// //   const navigate = useNavigate();

// //   function handleChange(e) {
// //     setFormData({ ...formData, [e.target.name]: e.target.value });
// //   }

// //   function handleSubmit(e) {
// //     e.preventDefault();

// //     if (formData.username === "chirag@gmail.com" && formData.password === "1234567") {
// //       alert("Login successful!");
// //       navigate("/Overview"); 
// //     } else {
// //       alert("Invalid credentials!");
// //     }
// //   }

// //   return (
// //     <section>
// //       {/* Background grid */}
// //       <div className="grid">
// //         {Array.from({ length: 60 }).map((_, i) => (
// //           <span key={i}></span>
// //         ))}
// //       </div>

// //       {/* Login box */}
// //       <div className="signin">
// //         <form onSubmit={handleSubmit}>
// //           <h2>ADMIN LOGIN</h2>
// //           <input
// //             type="text"
// //             name="username"
// //             placeholder="Username"
// //             value={formData.username}
// //             onChange={handleChange}
// //             required
// //           />
// //           <input
// //             type="password"
// //             name="password"
// //             placeholder="Password"
// //             value={formData.password}
// //             onChange={handleChange}
// //             required
// //           />
// //           <div className="links">
// //             <a href="#">Forgot Password?</a>
// //             <a href="#">Help</a>
// //           </div>
// //           <button type="submit">Login</button>
// //         </form>
// //       </div>
// //     </section>
// //   );
// // }

// import React from "react";

// import { useState } from 'react';
// import { useDispatch } from 'react-redux';
// import { loginSuccess } from '../../features/authSlice';
// import './AdminLogin.css';

// export default function AdminLogin(){
//   const [form,setForm] = useState({username:'',password:''});
//   const dispatch = useDispatch();

//   const submit = (e)=>{
//     e.preventDefault();
//     if(form.username==='admin' && form.password==='1234'){
//       dispatch(loginSuccess({user:{role:'admin',name:'Admin'}}));
//     } else {
//       alert('Invalid admin credentials: try admin / 1234');
//     }
//   };

//   return (
//     <div className='card2'>
//       <h3 style={{color:"rgb(215, 220, 163);"}}>Admin Login</h3>
//       <form onSubmit={submit}>
//         <input name='username' placeholder='Username' value={form.username} onChange={e=>setForm({...form,username:e.target.value})} required/>
//         <input name='password' type='password' placeholder='Password' value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required/>
//         <div style={{marginTop:12}}><button className='button' type='submit'>Login as Admin</button></div>
//       </form>
     
//     </div>
//   );
// }
// Sidebar.jsx
import { NavLink, useNavigate } from "react-router-dom";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { logout } from "../../features/authSlice";  // ✅ adjust path


export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const PageData = [
    { id: 1, title: "Overview", path: "/overview", icon: "fas fa-tachometer-alt" },
    { id: 2, title: "Add Book", path: "/addbook", icon: "fas fa-plus" },
    { id: 3, title: "Books", path: "/book", icon: "fas fa-book" },
    { id: 4, title: "Members", path: "/member", icon: "fas fa-users" },
  ];

  // ✅ Logout handler
  const handleLogout = () => {
    dispatch(logout());
    localStorage.removeItem("auth");
    navigate("/admin-login"); // 👈 redirect to AdminLogin page
  };

  return (
    <div className="layout">
      <div className="top-navbar">
        <div className="left">
          <button className="toggle-btn" onClick={() => setIsOpen(!isOpen)}>
            <i className="fas fa-bars"></i>
          </button>
          <span className="logo">The Readers Planet</span>
        </div>

        {/* ✅ Profile + Logout */}
        <div className="right">
          <div className="profile">
            <i className="fas fa-user-circle"></i>
            <div className="profile-info">
              <span className="role">ADMIN</span>
              <span className="status">
                <span className="dot"></span> Online
              </span>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt"></i> LogOut
          </button>
        </div>
      </div>

      <div className={`sidebar-container ${isOpen ? "open" : "closed"}`}>
        <nav className="sidebar">
          <div className="list-group">
            {PageData.map((el) => (
              <NavLink
                key={el.id}
                to={el.path}
                className={({ isActive }) =>
                  "list-group-item" + (isActive ? " active" : "")
                }
              >
                <i className={`${el.icon} fa-fw me-3`}></i>
                {isOpen && <span>{el.title}</span>}
              </NavLink>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
}
