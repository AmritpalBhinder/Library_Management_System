import { Routes, Route, Navigate } from "react-router-dom";
import "./App.css";

import Overview from "./screens/Overview/Overview.jsx";
import AddBook from "./screens/AddBooks/AddBook.jsx";
import Books from "./screens/Books/Books.jsx";
import Members from "./screens/Members/Members.jsx";
import Sidebar from "./Components/Navbar/Navbar.jsx";
import AdminLogin from "./screens/AdminLogin/AdminLogin.jsx" 


export default function App() {
  return (
    <div className="app">
      {/* Sidebar always visible */}
      <Sidebar />

      <div className="content">
        <Routes>
          <Route path="/" element={<Overview />} />
          <Route path="/overview" element={<Overview />} />
          <Route path="/addbook" element={<AddBook />} />
          <Route path="/book" element={<Books />} />
          <Route path="/member" element={<Members />} />
 <Route path="/admin-login" element={<AdminLogin />} />


          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  );
}
