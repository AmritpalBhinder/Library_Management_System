import { NavLink, useNavigate } from "react-router-dom";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { logout } from "../../features/authSlice";
import "./navbar.css";

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const PageData = [
    { id: 1, title: "Overview", path: "/overview", icon: "fas fa-tachometer-alt" },
    { id: 2, title: "Add Book", path: "/addbook", icon: "fas fa-plus" },
    { id: 3, title: "Books", path: "/book", icon: "fas fa-book" },
    { id: 4, title: "Members", path: "/member", icon: "fas fa-users" },
  ];

  // ✅ Logout handler
  const handleLogout = () => {
    // clear redux state
    dispatch(logout());

    // clear localStorage
    localStorage.removeItem("auth");

    // redirect to AdminLogin page
    navigate("/adminlogin");   // 👈 yaha pe AdminLogin.jsx ka route dalo
  };

  return (
    <div className="layout">
      {/* ✅ Top Navbar */}
      <div className="top-navbar">
        <div className="left">
          <button className="toggle-btn" onClick={() => setIsOpen(!isOpen)}>
            <i className="fas fa-bars"></i>
          </button>
          <span className="logo">The Readers Planet</span>
        </div>

        {/* ✅ Profile + Logout */}
        <div className="right">
          <div className="profile">
            <i className="fas fa-user-circle"></i>
            <div className="profile-info">
              <span className="role">ADMIN</span>
              <span className="status">
                <span className="dot"></span> Online
              </span>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <i className="fas fa-sign-out-alt"></i> LogOut
          </button>
        </div>
      </div>

      {/* ✅ Sidebar */}
      <div className={`sidebar-container ${isOpen ? "open" : "closed"}`}>
        <nav className="sidebar">
          <div className="list-group">
            {PageData.map((el) => (
              <NavLink
                key={el.id}
                to={el.path}
                className={({ isActive }) =>
                  "list-group-item" + (isActive ? " active" : "")
                }
              >
                <i className={`${el.icon} fa-fw me-3`}></i>
                {isOpen && <span>{el.title}</span>}
              </NavLink>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
}
